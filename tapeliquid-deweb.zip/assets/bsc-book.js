globalThis.TAPELIQUID_BSC_BOOK = "";
